#!/usr/bin/env python

'Example for Handover'

from mininet.node import RemoteController
from mn_wifi.link import wmediumd
from mn_wifi.wmediumdConnector import interference
from subprocess import call

import sys
from mininet.log import setLogLevel, info
from mininet.term import makeTerm
from mn_wifi.cli import CLI
from mn_wifi.net import Mininet_wifi
from mn_wifi.node import Station, UserAP, OVSKernelAP
from mininet.link import Intf
from mn_wifi.associationControl import AssociationControl as AssCtrl
import time
import csv
import numpy as np
import pandas as pd
import mcdm
import random

class netTopo():
    global net, stas, APs
    def topology(args):
        "Create a network."
       
        
        #Creating the length/set of APs and Stations for each iteration    
        STALengths = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
        iterationLengthSta = len(STALengths)
  

        APLengths = [5, 9, 17, 21]
        iterationLengthAPs = len(APLengths)
        
        net = Mininet_wifi(accessPoint=OVSKernelAP, link=wmediumd, wmediumd_mode=interference, ac_method='ssf')

        info("*** Creating nodes\n")
        info('*** Add hosts/stations\n')
        
        stas = []
        # for i in range(iterationLengthSta):
        #     STALength = STALengths[i]

        for i in range(STALengths[0]):
            
            
        #     #Slow-moving station
        #     sta = net.addStation(f"sta{i+1}", ip = f"10.0.0.{i+1}",min_x=17, max_x=65, min_y=27, max_y=70, min_v=0.5, max_v=1,  freq_list='2.412,5.2', mode='g,ax5')
        #     stas.append(sta)
        # print(stas)
            sta = net.addStation(f"sta{i+1}", ip = f"10.0.0.{i+1}",min_x=10, max_x=120, min_y=10, max_y=120, min_v=0.15, max_v=0.35, freq_list='2.412,5.2', mode='g,ax5', staLength = STALengths[0], apLength=APLengths[0])

            stas.append(sta)
        print(stas)
        
            #Fast-moving station
            #APs = ?

            #sta = net.addStation(f"sta{i+1}", ip = f"10.0.0.{i+1}",min_x=10, max_x=120, min_y=10, max_y=120, min_v=1.5, max_v=2, freq_list='2.412,5.2', mode='g,ax5', staLength = STALength[0])
            
            #APs = 4
            # sta = net.addStation(f"sta{i+1}", ip = f"10.0.0.{i+1}",min_x=17, max_x=65, min_y=27, max_y=80, min_v=1, max_v=1.4, freq_list='2.412,5.2', mode='g,ax5', staLength = STALength[7])
            
            #sta = net.addStation(f"sta{i+1}", ip = f"10.0.0.{i+1}",min_x=10, max_x=120, min_y=10, max_y=120, min_v=1.5, max_v=2, freq_list='2.412,5.2', mode='g,ax5', staLength = STALength[7])

            #stas.append(sta)
        #print(stas)

       
        info('*** Add APs\n')
        APChannelList = [36, 40, 44, 48, 149, 153, 157, 161, 36, 165, 36, 40, 44, 48, 149, 153, 157, 161, 165, 36, 40]
        
        #modes = ['g','ax5']
        APs = []
        #AP iterations

        positions = ['50,50,0','30,83,0', '65,83,0', '36,50,0', '70,50,0', '115,35,0', '105,70,0', '15,25,0', '30,125,0']

        # positions = [   '90,100,0','70,133,0', '105,133,0', '76,100,0', # 4
        #                 '110,100,0', '155,85,0', '145,120,0', '55,75,0', '70,175,0', # 9
        #                 '20,80,0', '38,45,0', '55,15,0', '85,20,0', '115,15,0', '145,30,0', '135,55,0', '105,40,0', # 17
        #                 '105,180,0', '15,110,0', '20,140,0', '35,170,0' # 21
        #             ] 
        
        
        #Stations iteration
        # positions = ['50,50,0','30,70,0', '70,70,0', '36,40,0', '60,40,0']

        for i in range(APLengths[0]):

            #APs
            if i ==0:

                AP = net.addAccessPoint(f"ap{i+1}", cls=OVSKernelAP, ssid = f'ap{i+1}-ssid',
                                 channel=1, mode='g', position= positions[i],range = 95)
                APs.append(AP)
                
            else:
                AP = net.addAccessPoint(f"ap{i+1}", cls=OVSKernelAP, ssid = f'ap{i+1}-ssid',
                                 channel=APChannelList[i-1], mode='ax5', position=positions[i])
                APs.append(AP)
        print(APs)
        
        info('*** Adding controller\n')
        c1 = net.addController('c1')

        "Propagation model"
        net.setPropagationModel(model="logDistance", exp=5)

        info("*** Configuring wifi nodes\n")
        net.configureWifiNodes()
        

        info("*** Creating links\n")
        for i in range(APLengths[0]-1):
            net.addLink(APs[i],APs[i+1])

        "Plotting graph"

        if '-p' not in args:
            net.plotGraph(max_x=200, max_y=200)

        "Mobility model: Random Direction"
        if '-s' not in args:
            #net.startMobility(time=0, ac_method='ssf')

            net.setMobilityModel(time=0, model='RandomDirection',max_x=200, max_y=200, seed=6)
            #print("TIME:", time.time())
            
            #net.stopMobility(time=60)

   

        info("*** Starting network\n")
        net.build()
        c1.start()
        for ap in APs:
            ap.start([c1])
        
        info("*** Running CLI\n")
        CLI(net)

        
        info("*** Stopping network\n")
        net.stop()
 

if __name__ == '__main__':
        setLogLevel('info')
        netTopo.topology(sys.argv)

